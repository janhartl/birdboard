use crate::app::App;

use ratatui::Frame;
use ratatui::layout::Alignment;
use ratatui::widgets::Paragraph;

pub fn draw(frame: &mut Frame, app: &App) {
    let strategy = Paragraph::new("Strategy").alignment(Alignment::Center);
    let no_tatum = Paragraph::new("NO TATUM").alignment(Alignment::Center);
    let has_tatum = app.team_has_player(app.user_team_id, 6);

    if has_tatum {
        frame.render_widget(strategy, frame.area());
    } else {
        frame.render_widget(no_tatum, frame.area());
    }
}
