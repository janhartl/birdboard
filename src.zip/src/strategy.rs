use ratatui::Frame;

pub fn draw(frame: &mut Frame, _app: &App) {
    let strategy = Paragraph::new("Strategy").alignment(Alignment::Center);

    frame.render_widget(strategy, frame.area());
}
